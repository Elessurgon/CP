import java.util.ArrayList;
import java.util.Arrays;

public class Board {
    private final int[][] board;
    private final int n;

    // create a board from an n-by-n array of tiles,
    // where tiles[row][col] = tile at (row, col)
    public Board(int[][] tiles) {
        n = tiles[0].length;
        board = copyMatrix(tiles);
    }

    // string representation of this board
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append(n + "\n");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                s.append(String.format("%2d ", board[i][j]));
            }
            s.append("\n");
        }
        return s.toString();
    }

    // board dimension n
    public int dimension() {
        return n;
    }

    // number of tiles out of place
    public int hamming() {
        int hammingCount = 0;
        int count = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                count++;
                if (board[i][j] != count && board[i][j] != 0) {
                    hammingCount += 1;
                }
            }
        }
        return hammingCount;
    }

    // sum of Manhattan distances between tiles and goal
    public int manhattan() {
        int manhattanCount = 0;
        int count = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                count++;
                if (!(board[i][j] == count) && board[i][j] != 0) {
                    int realRow = getRow(board[i][j]);
                    int realCol = getCol(board[i][j]);
                    manhattanCount += Math.abs(i - realRow) + Math.abs(j - realCol);
                }
            }
        }
        return manhattanCount;
    }

    // is this board the goal board?
    public boolean isGoal() {
        return hamming() == 0;
    }

    // does this board equal y?
    public boolean equals(Object y) {
        if (y == null) {
            return false;
        }

        if (this.getClass() != y.getClass()) {
            return false;
        }

        Board otherBoard = (Board) y;
        return Arrays.deepEquals(this.board, otherBoard.board);
    }

    // all neighboring boards
    public Iterable<Board> neighbors() {
        ArrayList<Board> neighborsList = new ArrayList<Board>();

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (this.board[i][j] == 0) {
                    // exchange with top
                    int[][] neighbour;
                    if (i > 0) {
                        neighbour = copyMatrix(board);
                        neighbour[i][j] = neighbour[i - 1][j];
                        neighbour[i - 1][j] = 0;
                        neighborsList.add(new Board(neighbour));
                    }

                    // exchange with bottom
                    if (i < (n - 1)) {
                        neighbour = copyMatrix(board);
                        neighbour[i][j] = neighbour[i + 1][j];
                        neighbour[i + 1][j] = 0;
                        neighborsList.add(new Board(neighbour));
                    }

                    // exchange with left
                    if (j > 0) {
                        neighbour = copyMatrix(board);
                        neighbour[i][j] = neighbour[i][j - 1];
                        neighbour[i][j - 1] = 0;
                        neighborsList.add(new Board(neighbour));
                    }

                    // exchange with right
                    if (j < (n - 1)) {
                        neighbour = copyMatrix(board);
                        neighbour[i][j] = neighbour[i][j + 1];
                        neighbour[i][j + 1] = 0;
                        neighborsList.add(new Board(neighbour));
                    }
                }
            }
        }
        return neighborsList;

    }

    // a board that is obtained by exchanging any pair of tiles
    public Board twin() {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n - 1; j++) {
                if ((board[i][j] != 0) && (board[i][j + 1] != 0)) {
                    int[][] neighbour = copyMatrix(board);
                    int temp;
                    temp = neighbour[i][j + 1];
                    neighbour[i][j + 1] = neighbour[i][j];
                    neighbour[i][j] = temp;
                    return new Board(neighbour);
                }
            }
        }
        return null;
    }


    // unit testing (not graded)
    public static void main(String[] args) {
    }

    private int getRow(int number) {
        return (number - 1) / n;
    }

    private int getCol(int number) {
        return (number - 1) % n;
    }

    private int[][] copyMatrix(int[][] oldMatrix) {
        int[][] newMatrix = new int[this.n][this.n];
        for (int i = 0; i < this.n; i++) {
            for (int j = 0; j < this.n; j++) {
                newMatrix[i][j] = oldMatrix[i][j];
            }
        }
        return newMatrix;
    }

}
