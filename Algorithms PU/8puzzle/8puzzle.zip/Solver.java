import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

import java.util.Comparator;

public class Solver {


    private Node goal;

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        if (initial == null) {
            throw new IllegalArgumentException("Argument is null");
        }
        goal = null;
        Node initialNode = new Node(initial, null);
        Node initalTwinNode = new Node(initial.twin(), null);

        MinPQ<Node> pq = new MinPQ<Node>(initialNode);
        pq.insert(initialNode);

        MinPQ<Node> pqTwin = new MinPQ<Node>(initalTwinNode);
        pqTwin.insert(initalTwinNode);

        while (!pq.isEmpty() || !pqTwin.isEmpty()) {
            if (check(pq)) {
                break;
            }

            if (check(pqTwin)) {
                goal = null;
                break;
            }
        }
    }


    // is the initial board solvable? (see below)
    public boolean isSolvable() {
        if (goal != null) {
            return true;
        }
        return false;
    }

    // min number of moves to solve initial board
    public int moves() {
        if (!isSolvable()) {
            return -1;
        }
        return countMoves(goal);

    }

    // sequence of boards in a shortest solution
    public Iterable<Board> solution() {
        if (!isSolvable()) {
            return null;
        }

        Stack<Board> result = new Stack<>();
        Node current = goal;
        result.push(current.boardState);
        while (current.previousNode != null) {
            current = current.previousNode;
            result.push(current.boardState);
        }
        return result;
    }

    // test client (see below)
    public static void main(String[] args) {
        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                tiles[i][j] = in.readInt();
        Board initial = new Board(tiles);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable()) StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }

    private boolean check(MinPQ<Node> pq) {
        Node currentNode = pq.delMin();
        Board currentBoard = currentNode.boardState;

        if (currentBoard.isGoal()) {
            goal = currentNode;
            return true;
        }
        for (Board n : currentBoard.neighbors()) {
            if (currentNode.previousNode == null || !currentNode.previousNode.boardState.equals(n)) {
                pq.insert(new Node(n, currentNode));
            }
        }
        return false;

    }

    private int countMoves(Node node) {
        if (node == null) {
            return 0;
        }
        int moves = 0;
        Node current = node;
        while (current.previousNode != null) {
            current = current.previousNode;
            moves++;
        }
        return moves;
    }

    private class Node implements Comparator<Node> {
        public Board boardState;
        public int moves;
        public int priority;
        public Node previousNode;
        public int manhattan;

        private Node(Board boardstate, Node previousNode) {
            if (boardstate == null) {
                throw new IllegalArgumentException("Currrent Board State cant be null");
            }

            this.boardState = boardstate;
            this.previousNode = previousNode;
            this.moves = countMoves(previousNode);
            this.manhattan = boardstate.manhattan();
            this.priority = manhattan + this.moves;

        }

        public int compare(Node o1, Node o2) {
            return Integer.compare(o1.priority, o2.priority);

        }
    }

}
