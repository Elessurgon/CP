import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.Queue;

public class KdTree {
    private Node root;
    private int size;

    public KdTree() {
        root = null;
        size = 0;
    }                              // construct an empty set of points

    public boolean isEmpty() {
        return size == 0;
    }                      // is the set empty?

    public int size() {
        return size;
    }                         // number of points in the set

    public void insert(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException("Point is null");
        }
        root = insert(root, p, true, true, new RectHV(0, 0, 1, 1));
    }             // add the point to the set (if it is not already in the set)

    private Node insert(Node current, Point2D p, boolean isVertical, boolean isLeftOrBottom, RectHV rect) {
        if (isEmpty()) {
            size++;
            return new Node(p, new RectHV(0, 0, 1, 1));
        }
        if (current == null) {
            RectHV rectangle;
            size++;
            if (isVertical) {
                if (isLeftOrBottom) {
                    rectangle = new RectHV(rect.xmin(), rect.ymin(), p.x(), rect.ymax());
                } else {
                    rectangle = new RectHV(p.x(), rect.ymin(), rect.xmax(), rect.ymax());
                }
            } else {
                if (isLeftOrBottom) {
                    rectangle = new RectHV(rect.xmin(), rect.ymin(), rect.xmax(), p.y());
                } else {
                    rectangle = new RectHV(rect.xmin(), p.y(), rect.xmax(), rect.ymax());
                }
            }
            return new Node(p, rectangle);
        }
        if (current.point.equals(p)) {
            return current;
        }
        if (isVertical) {
            if (current.point.x() > p.x()) {
                current.left = insert(current.left, p, !isVertical, true, current.rect);
            } else {
                current.right = insert(current.right, p, !isVertical, false, current.rect);
            }
        } else {
            if (current.point.y() > p.y()) {
                current.left = insert(current.left, p, !isVertical, true, current.rect);
            } else {
                current.right = insert(current.right, p, !isVertical, false, current.rect);
            }
        }
        return current;
    }

    public boolean contains(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException("Point is null");
        }
        return contains(root, p, true);
    }           // does the set contain point p?

    private boolean contains(Node current, Point2D p, boolean isVertical) {
        if (current == null) {
            return false;
        }
        if (current.point.equals(p)) {
            return true;
        }
        if (isVertical) {
            if (current.point.x() > p.x()) {
                return contains(current.left, p, !isVertical);
            } else {
                return contains(current.right, p, !isVertical);
            }
        } else {
            if (current.point.y() > p.y()) {
                return contains(current.left, p, !isVertical);
            } else {
                return contains(current.right, p, !isVertical);
            }
        }
    }

    public void draw() {

    }                        // draw all points to standard draw

    public Iterable<Point2D> range(RectHV rect) {
        if (rect == null) {
            throw new IllegalArgumentException("Rectangle is null");
        }

        Queue<Point2D> queue = new Queue<Point2D>();
        range(root, rect, queue);
        return queue;
    }            // all points that are inside the rectangle (or on the boundary)

    private void range(Node current, RectHV rect, Queue<Point2D> queue) {
        if (current == null) {
            return;
        }
        if (rect.contains(current.point)) {
            queue.enqueue(current.point);
        }
        if (current.left != null && rect.intersects(current.left.rect)) {
            range(current.left, rect, queue);
        }
        if (current.right != null && rect.intersects(current.right.rect)) {
            range(current.right, rect, queue);
        }
    }

    public Point2D nearest(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException("Point is null");
        }
        if (isEmpty()) return null;
        return nearest(root, p, root.point, true);
    }            // a nearest neighbor in the set to point p; null if the set is empty

    private Point2D nearest(Node current, Point2D p, Point2D nearest, boolean isVertcal) {
        Point2D mininum = nearest;
        if (current == null) {
            return mininum;
        }
        if (current.point.distanceSquaredTo(p) < nearest.distanceSquaredTo(p)) {
            mininum = current.point;
        }
        if (isVertcal) {
            if (current.point.x() < p.x()) {
                mininum = nearest(current.right, p, mininum, !isVertcal);
                if (current.left != null && (mininum.distanceSquaredTo(p) > current.left.rect.distanceSquaredTo(p)))
                    mininum = nearest(current.left, p, mininum, !isVertcal);
            } else {
                mininum = nearest(current.left, p, mininum, !isVertcal);
                if (current.right != null && (mininum.distanceSquaredTo(p) > current.right.rect.distanceSquaredTo(p)))
                    mininum = nearest(current.right, p, mininum, !isVertcal);
            }
        } else {
            if (current.point.y() < p.y()) {
                mininum = nearest(current.right, p, mininum, !isVertcal);
                if (current.left != null && (mininum.distanceSquaredTo(p) > current.left.rect.distanceSquaredTo(p)))
                    mininum = nearest(current.left, p, mininum, !isVertcal);
            } else {
                mininum = nearest(current.left, p, mininum, !isVertcal);
                if (current.right != null && (mininum.distanceSquaredTo(p) > current.right.rect.distanceSquaredTo(p)))
                    mininum = nearest(current.right, p, mininum, !isVertcal);
            }
        }
        return mininum;
    }

    public static void main(String[] args) {

    }                 // unit testing of the methods (optional)

    private static class Node {
        private Point2D point;
        private RectHV rect;
        private Node left;
        private Node right;

        private Node(Point2D p, RectHV rect) {
            this.point = p;
            this.rect = rect;
            left = null;
            right = null;
        }
    }
}
