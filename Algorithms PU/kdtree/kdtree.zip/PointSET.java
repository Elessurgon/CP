import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.SET;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.Queue;

public class PointSET {

    private SET<Point2D> pointSet;

    public PointSET() {
        this.pointSet = new SET<Point2D>();
    }                               // construct an empty set of points

    public boolean isEmpty() {
        return pointSet.isEmpty();
    }                     // is the set empty?

    public int size() {
        return pointSet.size();
    }                         // number of points in the set

    public void insert(Point2D p) {
        pointSet.add(p);
    }              // add the point to the set (if it is not already in the set)

    public boolean contains(Point2D p) {
        return pointSet.contains(p);
    }            // does the set contain point p?

    public void draw() {
        for (Point2D p : pointSet) {
            StdDraw.point(p.x(), p.y());
        }
    }                        // draw all points to standard draw

    public Iterable<Point2D> range(RectHV rect) {
        if (rect == null) {
            throw new IllegalArgumentException("Rectangle is null");
        }

        Queue<Point2D> result = new Queue<>();
        for (Point2D p : pointSet) {
            if (rect.contains(p)) {
                result.enqueue(p);
            }
        }
        return result;
    }             // all points that are inside the rectangle (or on the boundary)

    public Point2D nearest(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException("Point is null");
        }
        if (pointSet == null) {
            return null;
        }
        Point2D nearestPoint = null;
        for (Point2D testPoint : pointSet) {
            if (nearestPoint == null) {
                nearestPoint = testPoint;
            }
            if (testPoint.distanceSquaredTo(p) < nearestPoint.distanceSquaredTo(p)) {
                nearestPoint = testPoint;
            }
        }
        return nearestPoint;
    }             // a nearest neighbor in the set to point p; null if the set is empty

    public static void main(String[] args) {
        /*this is gonna be empty
        im not sure what tests to include
        Study the algorithm better and redo it*/
    }                 // unit testing of the methods (optional)

}
