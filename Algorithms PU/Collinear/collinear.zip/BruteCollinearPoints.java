import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;

public class BruteCollinearPoints {
    // private LineSegment[] lineSegments;
    private ArrayList<LineSegment> lineSegmentList = new ArrayList<LineSegment>();

    // finds all line segments containing 4 points
    public BruteCollinearPoints(Point[] points) {

        if (points == null) {
            throw new IllegalArgumentException("args is null");
        }

        checkNullPoints(points);
        checkDuplicatedPoints(points);

        Point[] pointsSorted = Arrays.copyOf(points, points.length);
        Arrays.sort(pointsSorted);


        for (int p = 0; p < pointsSorted.length - 3; p++) {
            for (int q = (p + 1); q < pointsSorted.length - 2; q++) {
                for (int r = (q + 1); r < pointsSorted.length - 1; r++) {
                    if (pointsSorted[p].slopeOrder().compare(pointsSorted[q], pointsSorted[r]) == 0) {
                        for (int s = (r + 1); s < pointsSorted.length; s++) {
                            if (pointsSorted[p].slopeTo(pointsSorted[q]) == pointsSorted[p].slopeTo(pointsSorted[r])
                                    && pointsSorted[p].slopeTo(pointsSorted[q])
                                    == pointsSorted[p].slopeTo(pointsSorted[s])) {
                                lineSegmentList.add(new LineSegment(pointsSorted[p], pointsSorted[s]));

                            }
                        }
                    }
                }
            }
        }

        // lineSegments = lineSegmentList.toArray(new LineSegment[lineSegmentList.size()]);

    }

    // the number of line segments
    public int numberOfSegments() {
        return lineSegmentList.size();
    }

    // the line segments
    public LineSegment[] segments() {
        return lineSegmentList.toArray(new LineSegment[lineSegmentList.size()]);
    }

    private void checkDuplicatedPoints(Point[] pointsArg) {
        Point[] temp = Arrays.copyOf(pointsArg, pointsArg.length);
        Arrays.sort(temp);
        for (int i = 0; i < temp.length - 1; i++) {
            if (temp[i].equals(temp[i + 1])) {
                throw new IllegalArgumentException("Args has Duplicates");
            }
        }
    }

    private void checkNullPoints(Point[] pointsArg) {
        for (int i = 0; i < pointsArg.length; i++) {
            if (pointsArg[i] == null) {
                throw new IllegalArgumentException("Args has null");
            }
        }
    }

    public static void main(String[] args) {

        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        BruteCollinearPoints collinear = new BruteCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
