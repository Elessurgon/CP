import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;

public class FastCollinearPoints {
    // private LineSegment[] lineSegments;
    private ArrayList<LineSegment> lineSegmentList = new ArrayList<LineSegment>();

    public FastCollinearPoints(Point[] points) {

        if (points == null) {
            throw new IllegalArgumentException("args is null");
        }

        checkNullPoints(points);
        checkDuplicatedPoints(points);

        Point[] pointsSorted = Arrays.copyOf(points, points.length);

        for (int i = 0; i < pointsSorted.length; i++) {
            Point p = points[i];
            Arrays.sort(pointsSorted);
            Arrays.sort(pointsSorted, p.slopeOrder());
            int min = 0;

            while ((min < pointsSorted.length) && (p.slopeTo(pointsSorted[min]) == Double.NEGATIVE_INFINITY)) {
                min++;
            }

            int max = min;

            while (min < pointsSorted.length) {

                while ((max < pointsSorted.length) && (p.slopeTo(pointsSorted[max]) == p.slopeTo(pointsSorted[min]))) {
                    max++;
                }

                if ((max - min) >= 3) {
                    Point pMin;
                    Point pMax;

                    if (pointsSorted[min].compareTo(p) < 0) {
                        pMin = pointsSorted[min];
                    }
                    else {
                        pMin = p;
                    }

                    if (pointsSorted[max - 1].compareTo(p) > 0) {
                        pMax = pointsSorted[max - 1];
                    }
                    else {
                        pMax = p;
                    }

                    if (p.equals(pMin)) {
                        lineSegmentList.add(new LineSegment(pMin, pMax));
                    }
                }
                min = max;
            }
        }

    }    // finds all line segments containing 4 or more points

    // the number of line segments
    public int numberOfSegments() {
        return lineSegmentList.size();
    }

    // the line segments
    public LineSegment[] segments() {
        return lineSegmentList.toArray(new LineSegment[lineSegmentList.size()]);
    }

    private void checkDuplicatedPoints(Point[] pointsArg) {
        Point[] temp = Arrays.copyOf(pointsArg, pointsArg.length);
        Arrays.sort(temp);
        for (int i = 0; i < temp.length - 1; i++) {
            if (temp[i].equals(temp[i + 1])) {
                throw new IllegalArgumentException("Args has Duplicates");
            }
        }
    }

    private void checkNullPoints(Point[] pointsArg) {
        for (int i = 0; i < pointsArg.length; i++) {
            if (pointsArg[i] == null) {
                throw new IllegalArgumentException("Args has null");
            }
        }
    }


    public static void main(String[] args) {

        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
