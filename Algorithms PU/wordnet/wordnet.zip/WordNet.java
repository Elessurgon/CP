import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.DirectedCycle;
import edu.princeton.cs.algs4.In;

import java.util.ArrayList;
import java.util.HashMap;

public class WordNet {
    private HashMap<Integer, String> IDtoNoun;
    private HashMap<String, ArrayList<Integer>> nounToID;
    private int numberVertices;
    private SAP sap;

    // constructor takes the name of the two input files
    public WordNet(String synsets, String hypernyms) {
        if (synsets == null || hypernyms == null) {
            throw new IllegalArgumentException("Arg is null");
        }
        IDtoNoun = new HashMap<Integer, String>();
        nounToID = new HashMap<String, ArrayList<Integer>>();
        numberVertices = 0;
        formSynsets(synsets);
        formHypernyms(hypernyms);
    }

    private void formSynsets(String synsets) {
        In in = new In(synsets);
        String line;
        while ((line = in.readLine()) != null) {
            String[] strs = line.split(",");
            if (strs.length < 2) {
                continue;
            }
            ++numberVertices;
            int id = Integer.parseInt(strs[0]);
            IDtoNoun.put(id, strs[1]);
            String[] nouns = strs[1].split(" ");
            for (String noun : nouns) {
                ArrayList<Integer> ids = nounToID.get(noun);
                if (ids != null) {
                    ids.add(id);
                } else {
                    ArrayList<Integer> nounIDs = new ArrayList<>();
                    nounIDs.add(id);
                    nounToID.put(noun, nounIDs);
                }
            }
        }
    }

    private void formHypernyms(String hypernyms) {
        In in = new In(hypernyms);
        String line;
        Digraph digraph = new Digraph(numberVertices);
        while ((line = in.readLine()) != null) {
            String[] strs = line.split(",");
            if (strs.length < 2) {
                continue;
            }
            for (int i = 1; i < strs.length; i++) {
                digraph.addEdge(Integer.parseInt(strs[0]), Integer.parseInt(strs[i]));
            }
        }
        DirectedCycle dc = new DirectedCycle(digraph);
        if (dc.hasCycle()) {
            throw new IllegalArgumentException("Has cycle");
        }
        int root = 0;
        for (int i = 0; i < digraph.V(); i++) {
            if (digraph.outdegree(i) == 0) {
                root++;
            }
            if (root > 1) {
                throw new IllegalArgumentException("Has more than 1 root");
            }
        }
        sap = new SAP(digraph);
    }

    // returns all WordNet nouns
    public Iterable<String> nouns() {
        return nounToID.keySet();
    }

    // is the word a WordNet noun?
    public boolean isNoun(String word) {
        if (word == null) {
            throw new IllegalArgumentException("Arg is null");
        }
        return nounToID.containsKey(word);
    }

    // distance between nounA and nounB (defined below)
    public int distance(String nounA, String nounB) {
        if (nounA == null || nounB == null || !isNoun(nounA) || !isNoun(nounB)) {
            throw new IllegalArgumentException("Arg is null");
        }

        return sap.length(nounToID.get(nounA), nounToID.get(nounB));
    }

    // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // in a shortest ancestral path (defined below)
    public String sap(String nounA, String nounB) {
        if (nounA == null || nounB == null || !isNoun(nounA) || !isNoun(nounB)) {
            throw new IllegalArgumentException("Arg is null");
        }

        return IDtoNoun.get(sap.ancestor(nounToID.get(nounA), nounToID.get(nounB)));
    }

    // do unit testing of this class
    public static void main(String[] args) {
        // No tests
    }
}
